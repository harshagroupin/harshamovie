<!DOCTYPE html><html lang="en-IN"><head><meta charSet="utf-8"/><meta name="viewport" content="width=device-width"/><title></title><meta name="description" content=""/><link rel="canonical" href="https://www.district.in/movies/404"/><meta name="robots" content="noindex,follow"/><meta name="googlebot" content="noindex,follow,max-image-preview:large,max-snippet:-1"/><meta property="og:title" content=""/><meta property="og:description" content=""/><meta property="og:url" content="https://www.district.in/movies/404"/><meta property="og:type" content="website"/><meta property="og:site_name" content="District by Zomato"/><meta name="twitter:card" content="summary_large_image"/><meta name="twitter:title" content=""/><meta name="twitter:description" content=""/><meta name="next-head-count" content="15"/><meta http-equiv="Content-Type" content="text/html; charset=utf-8"/><meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/><meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"/><meta name="mobile-web-app-capable" content="yes"/><script type="application/ld+json">{"@context":"https://schema.org","@type":"WebSite","name":"District by Zomato","url":"https://www.district.in","potentialAction":{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://www.district.in/search?q={search_term_string}"},"query-input":"required name=search_term_string"}}</script><script type="application/ld+json">{"@context":"https://schema.org","@type":"Organization","name":"District by Zomato","url":"https://www.district.in","logo":"https://b.zmtcdn.com/data/edition_assets/1731516000703.png","sameAs":["https://www.instagram.com/district.in/","https://twitter.com/districtbyzomato","https://www.youtube.com/@district_in","https://play.google.com/store/apps/details?id=com.application.zomato.district","https://apps.apple.com/in/app/district-movies-events-dining/id6670536058"],"parentOrganization":{"@type":"Organization","name":"Zomato","url":"https://www.zomato.com"}}</script><link rel="icon" href="https://www.district.in/favicon.ico"/><link rel="preconnect" href="https://cdn.district.in"/><link rel="preconnect" href="https://b.zmtcdn.com"/><script>
									window.dataLayer = window.dataLayer || [];
									window.dataLayer.push({
										'user_id': null,
									});
								</script><script id="gtm-script">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-KLJ33WDM');</script><script id="facebook-pixel">!function(f,b,e,v,n,t,s)
	{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
	n.callMethod.apply(n,arguments):n.queue.push(arguments)};
	if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
	n.queue=[];t=b.createElement(e);t.async=!0;
	t.src=v;s=b.getElementsByTagName(e)[0];
	s.parentNode.insertBefore(t,s)}(window, document,'script',
	'https://connect.facebook.net/en_US/fbevents.js');
	fbq('init', '24259333643695423');
	fbq('track', 'PageView');</script><script>(function() {
	let storageSupported = true;
	if(typeof window !== 'undefined'){
		storageSupported = navigator?.cookieEnabled;
		if (!storageSupported) {
			Object.defineProperty(window, 'localStorage', {value: {
			  _data       : {},
			  setItem     : function(id, val) { return this._data[id] = String(val); },
			  getItem     : function(id) { return this._data.hasOwnProperty(id) ? this._data[id] : undefined; },
			  removeItem  : function(id) { return delete this._data[id]; },
			  clear       : function() { return this._data = {}; }
			} });
			Object.defineProperty(window, 'sessionStorage', {value: {
			  _data       : {},
			  setItem     : function(id, val) { return this._data[id] = String(val); },
			  getItem     : function(id) { return this._data.hasOwnProperty(id) ? this._data[id] : undefined; },
			  removeItem  : function(id) { return delete this._data[id]; },
			  clear       : function() { return this._data = {}; }
			} });	
		  }
	}
	
})()</script><link data-next-font="" rel="preconnect" href="/" crossorigin="anonymous"/><link rel="preload" href="https://cdn.district.in/movies-web/_next/static/css/a341fe7779598d33.css" as="style"/><link rel="stylesheet" href="https://cdn.district.in/movies-web/_next/static/css/a341fe7779598d33.css" data-n-g=""/><link rel="preload" href="https://cdn.district.in/movies-web/_next/static/css/fb58ab143f04b0af.css" as="style"/><link rel="stylesheet" href="https://cdn.district.in/movies-web/_next/static/css/fb58ab143f04b0af.css" data-n-p=""/><noscript data-n-css=""></noscript><script defer="" nomodule="" src="https://cdn.district.in/movies-web/_next/static/chunks/polyfills-42372ed130431b0a.js"></script><script src="https://cdn.district.in/movies-web/_next/static/chunks/webpack-a84077ea211156b1.js" defer=""></script><script src="https://cdn.district.in/movies-web/_next/static/chunks/framework-6603b6fce1ea64cf.js" defer=""></script><script src="https://cdn.district.in/movies-web/_next/static/chunks/main-dc3dae42fbd52c97.js" defer=""></script><script src="https://cdn.district.in/movies-web/_next/static/chunks/datadog-21fe86607f5a4992.js" defer=""></script><script src="https://cdn.district.in/movies-web/_next/static/chunks/pages/_app-879612874b2a3d1b.js" defer=""></script><script src="https://cdn.district.in/movies-web/_next/static/chunks/3975-82058f6255d44b62.js" defer=""></script><script src="https://cdn.district.in/movies-web/_next/static/chunks/7505-49655a1975640336.js" defer=""></script><script src="https://cdn.district.in/movies-web/_next/static/chunks/pages/404-8c5658de10527e3a.js" defer=""></script><script src="https://cdn.district.in/movies-web/_next/static/cZ94yJ4eH6ljjG5Vgfbwv/_buildManifest.js" defer=""></script><script src="https://cdn.district.in/movies-web/_next/static/cZ94yJ4eH6ljjG5Vgfbwv/_ssgManifest.js" defer=""></script></head><body><div id="__next"><div class="NotFoundPage_errorScreenContainer__s1_4p"><div class="NotFoundPage_verticallyCenter__IAirh"><div class="NoData_noData__ee_X5"><img alt="Not Found" loading="lazy" width="286" height="128" decoding="async" data-nimg="1" style="color:transparent" srcSet="https://cdn.district.in/movies-web/_next/static/media/not-found-icon.8f5b5e48.svg 1x, https://cdn.district.in/movies-web/_next/static/media/not-found-icon.8f5b5e48.svg 2x" src="https://cdn.district.in/movies-web/_next/static/media/not-found-icon.8f5b5e48.svg"/><h3 class="NotFoundPage_errorHeading__NkYpA">Sorry, something went wrong</h3><div class="NotFoundPage_errorSubHeading__JPqod">This page doesnt exist. Please go to Movies Homepage.</div><div class="NotFoundPage_roundButton__wtVUf">Go to Movies Home</div></div></div></div></div><script id="__NEXT_DATA__" type="application/json">{"props":{"pageProps":{}},"page":"/404","query":{},"buildId":"cZ94yJ4eH6ljjG5Vgfbwv","assetPrefix":"https://cdn.district.in/movies-web","nextExport":true,"autoExport":true,"isFallback":false,"scriptLoader":[]}</script><script>
									document.documentElement.setAttribute('data-theme', 'district-website');
							</script></body></html>